# Les Ailes Website Readme

## Student Information
**Student ID:** 00016004

## Project Overview
The "Les Ailes" website is designed and developed to provide a visually appealing and functionally powerful online presence. The use of up-to-date web design standards, including HTML5, CSS3, and JavaScript, ensures a seamless and enjoyable experience for visitors exploring the gastronomic world of Les Ailes.

## Web Design Standards
- **HTML5, CSS3, and JavaScript:** The site leverages the latest web design standards for a modern and unified appearance.
- **Navigation Bar:** Carefully designed with HTML, featuring a logo, menu items, and a separate basket area. The bar has a polished look with rounded borders that change to a pink tint on hover. The fixed position ensures it stays at the top during scrolling for an enhanced user experience.

## Responsive Homepage
- **Fully Responsive Design:** Created using HTML and CSS for a centered homepage with an eye-catching picture.
- **Product Boxes:** Harmoniously integrated three product boxes with photographs, product data, and an intriguing plus symbol.

## About Us Page
- **Centered Text Block:** The "About Us" page is enhanced with CSS and HTML for a centered text block.
- **Font Size and Spacing:** Quick adjustments were made to font size and spacing, improving both readability and presentation.

## Contacts Section
- **Customizable Form:** Utilizes HTML for structured form components, including text inputs, a feedback textarea, and a submit button.
- **Multilingual Support:** Labels and blanks on the form are presented in both English and Russian.
- **CSS Styling:** Ensures an uncluttered design, enhancing the overall user experience.
- **JavaScript Functionality:** Integration of JavaScript for form functionality, preventing automatic submission, minimal validation, and user-friendly error warnings.

## Integrated Google Map
- **Live, Interactive Map:** Effortlessly linked into the website using the Google Maps API.
- **API Key:** Ensures a secure connection to Google's resources, providing an accurate position of Les Ailes.

## Technologies Used
- **HTML:** Framework for the website's structure.
- **CSS:** Adds presentational polish for a visually attractive design.
- **JavaScript:** Provides dynamic features for improved user interaction.

## Conclusion
The confluence of HTML, CSS, and JavaScript technologies results in a website that not only looks appealing but also functions seamlessly. The Les Ailes website is ready to offer a wonderful experience to visitors exploring the world of gastronomy.