function hoverEffect(element) {
    element.style.transform = "scale(1.05)";
}

function normalSize(element) {
    element.style.transform = "scale(1)";
}
